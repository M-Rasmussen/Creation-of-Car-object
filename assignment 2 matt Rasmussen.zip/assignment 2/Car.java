import java.text.DecimalFormat;
import java.util.Calendar;

public class Car
{


	private int year;
	private double price;
	private String vin;
	private static int objectCount = 0;

	private final int MINYEAR = 1950;
	private final int MAXYEAR = 2020;
	private final double MINPRICE = 0;
	private final double MAXPRICE =100000;



	public void setVin(String v) throws CarException //setter vin
		{
			if(v != null && !v.isEmpty() && !v.trim().isEmpty())
				vin=v;		//set valid vin
			else
				throw new CarException("Cannot modify object. Vin is invalid "); // exception
		}//end set Vin


	public String getVin()	//return vin
		{
			return vin;
		}//end getVin


	public void setYear(int y) throws CarException //setter year
	{
		if(y>=MINYEAR && y<=MAXYEAR)		//if value good
			year=y;
		else
			throw new CarException("Connot modify object. Year is invalid");  //exception
	}//end set year


//return year
	public int getyear()
	{
		return year;
	}//end return year

	public void setPrice(double p) throws CarException //set price
		{
			if(p>=MINPRICE && p<=100000)
				price=p;	//if value good
			else
				throw new CarException("Cannot modify object. Price is invalid"); // exception
		} //end setprice
//return price
	public double getPrice()
		{
			return price;
		}//end get price

	public Car()			// default constructor
		{
			Calendar c = Calendar.getInstance();	//import calendar

			vin = "N/A";
			year = c.get(Calendar.YEAR);
			price = MINPRICE;

			objectCount ++;
		}//end default constructor

	public Car(String v, int y, double p) throws CarException	// overloaded constructor
		{
			setVin(v);
			setYear(y);
			setPrice(p);

			objectCount ++;

		}//end overloaded constructor
	public String toString()
	{
		    DecimalFormat df = new DecimalFormat("#.00"); //import decimal format

		return "A car with a vin of " + vin + ", which is made in " + year + ", and costing $" + df.format(price);
		}//end to string

	protected void finalize()
	{
		objectCount--;

	}//end finalize

	public static int getCount()
	{
		return objectCount;
	}
}//end of class