// creates exception class that will be called by bag class
public class CarException extends Exception
{
	private String message;

	public CarException(String m)
	{
		message=m;
	}

	public String toString()
	{
		return message;
	}

}// end of car exception class